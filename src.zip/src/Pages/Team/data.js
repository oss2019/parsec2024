const teamsData = [
  {
    name: "ORGANIZER",
    members: [
      {
        name: "ORGANIZER",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "https://in.linkedin.com/in/narendramodi",
        twitter: "https://youtu.be/dQw4w9WgXcQ",
        instagram: "https://www.instagram.com/virat.kohli/",
      },
    ],
  },

  {
    name: "WEB-TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "https://youtu.be/dQw4w9WgXcQ",
        twitter: "https://twitter.com/elonmusk/",
        instagram: "https://www.instagram.com/virat.kohli/",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "https://in.linkedin.com/in/narendramodi",
        twitter: "https://twitter.com/elonmusk/",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "https://youtu.be/dQw4w9WgXcQ",
        instagram: "https://www.instagram.com/virat.kohli/",
      },
    ],
  },

  {
    name: "SPACE DATA SCIENCE TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "https://youtu.be/dQw4w9WgXcQ",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
    ],
  },

  {
    name: "ARTIFICIAL INTELLIGENCE TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
    ],
  },

  {
    name: "ROBOTICS TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
    ],
  },

  {
    name: "FINANCE TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
    ],
  },

  {
    name: "CODING TEAM",
    members: [
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
      {
        name: "XYZ",
        image: "/Team/xyz.jpg",
        email: "",
        linkedin: "",
        twitter: "",
        instagram: "",
      },
    ],
  },
];

export default teamsData;
