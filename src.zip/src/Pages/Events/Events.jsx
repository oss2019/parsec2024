import "./Events.css"
import "./Events.module.css"
import EventCard from "./EventCard/EventCard"
import EventsData from "./data"
import imge from './parsec-logo.png'
function Events() {
  const eventData = {
    heading: "Event Heading",
    content: "Event Content",
    knowMoreLink: "https://example.com",
    image: {imge},
  };
  return (
    <>
      <div className="content-wrapper">
        <section id="hero-section-1" className="section-main">
          <div className="hero-content-wrapper">
            <div className="hero-main">
              <h1>Parsec4.0</h1>
              <div className={"hero-quote-wrapper"}>
                <div className={"style-quote-bar"}></div>
                <div className={"hero-quote"}>
                 <EventCard
                    leftSideImage={true} // Example value for leftSideImage
                    data={eventData} // Pass the eventData object
                    number={1} // Example value for number
                  /> 
                </div>
              </div>
            </div>
          </div>
          
       </section>  
      </div>
  </>
  )
}

export default Events