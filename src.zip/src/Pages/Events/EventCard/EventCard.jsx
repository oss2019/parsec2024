import styles from "./EventCard.module.css"

export default function EventCard({ leftSideImage, data, number }) {
  return (
    <>
      <div className={styles.eventCardWrapper}>
        <div className={styles.eventCardMain}>
          <div
            className={`${styles.eventInfo} ${
              leftSideImage && styles.eventInfoLeft
            }`}
          >
            <div className={styles.eventNumber}>
              <h1>{number < 10 ? `0${number}` : number}</h1>
              <div className={styles.styleDiv}></div>
            </div>
            <div className={styles.eventName}>
              <h1>{data.heading}</h1>
            </div>
            <div className={styles.eventInfo}>{data.content}</div>
            <div className={styles.knowMore}>
              <a href={data.knowMoreLink} target="_blank">
                <div>Know More</div>
                <div className={styles.buttonImage}>
                  <img
                    src={`${"/Events/event-button.svg"}`}
                    alt="button"
                  />
                </div>
              </a>
            </div>
          </div>
          <div
            className={`${styles.eventImageWrapper} ${
              leftSideImage && styles.eventImageWrapperLeft
            }`}
          >
            <div className={styles.eventImageCard}>
              <img src={data.image}  />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
