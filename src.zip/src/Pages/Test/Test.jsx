function Test() {
  return <div style={{ color: "#fff" }}>Hello Test</div>
}

export default Test
